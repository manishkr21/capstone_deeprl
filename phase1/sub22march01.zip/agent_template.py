"""
OBELIX Robot Policy - D3QN-PER Agent Template

This file contains the trained D3QN-PER policy for the OBELIX robot control task.
The evaluation system will import and call the policy() function.

Architecture:
- Dueling Double DQN (D3QN) with Prioritized Experience Replay (PER)
- Input: 72-dim stacked observations (18 sensors × 4 frames)
- Output: Q-values for 5 discrete actions
- Network: 4 hidden layers of 512 units each with dueling heads

Requirements:
- No additional training during evaluation
- All model weights pre-loaded from checkpoint
- CPU-only inference (no CUDA required)
- Fast deterministic greedy action selection
"""

import os
from typing import Optional, Sequence

import numpy as np
import torch
import torch.nn as nn

# ============================================================================
# Constants
# ============================================================================

ACTIONS: Sequence[str] = ("L45", "L22", "FW", "R22", "R45")
OBS_DIM = 72  # 18 sensors × 4 frame stack (n_stack=4)
ACTION_DIM = len(ACTIONS)


# ============================================================================
# Dueling DQN Network (Matches Training Architecture)
# ============================================================================

class DuelingDQN(nn.Module):
    """
    Dueling DQN network matching the D3QN-PER training agent.
    
    Architecture:
    - Shared trunk: 4 dense layers, 512 units each, ReLU activation
    - Value head: outputs V(s) - scalar state value
    - Advantage head: outputs A(s,a) - per-action advantage
    - Combination: Q(s,a) = V(s) + [A(s,a) - mean(A)]
    
    Input shape: (batch, 72)
    Output shape: (batch, 5)
    """
    
    def __init__(
        self,
        obs_dim: int = OBS_DIM,
        n_actions: int = ACTION_DIM,
        hidden_dim: int = 512,
        n_layers: int = 4,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.n_actions = n_actions
        
        # ── Shared feature trunk ──────────────────────────────────────────
        layers = []
        in_dim = obs_dim
        for _ in range(n_layers):
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.ReLU())
            if dropout > 0.0:
                layers.append(nn.Dropout(p=dropout))
            in_dim = hidden_dim
        self.shared = nn.Sequential(*layers)
        
        # ── Value head (outputs V(s)) ─────────────────────────────────────
        self.value_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
        )
        
        # ── Advantage head (outputs A(s,a)) ───────────────────────────────
        self.advantage_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, n_actions),
        )
        
        self._init_weights()
    
    def _init_weights(self):
        """He initialization for ReLU networks."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, nonlinearity="relu")
                nn.init.zeros_(m.bias)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through dueling network.
        
        Args:
            x: Tensor of shape (batch, obs_dim)
            
        Returns:
            Q-values of shape (batch, n_actions)
        """
        # Shared feature extraction
        features = self.shared(x)
        
        # Value stream: scalar per state
        value = self.value_head(features)  # (batch, 1)
        
        # Advantage stream: per-action advantages
        advantage = self.advantage_head(features)  # (batch, n_actions)
        
        # Dueling combination: Q(s,a) = V(s) + A(s,a) - mean(A)
        # This ensures Q-values are meaningful and centered around value
        q = value + advantage - advantage.mean(dim=1, keepdim=True)
        
        return q


# ═══════════════════════════════════════════════════════════════════════════════
# Global Model Instance
# ═══════════════════════════════════════════════════════════════════════════════

_model: Optional[DuelingDQN] = None
_model_loaded = False


def _load_model(checkpoint_path: Optional[str] = None) -> None:
    """
    Load the trained D3QN-PER model weights.
    
    Called once on first policy call. Loads checkpoint from:
    1. Provided checkpoint_path (if given)
    2. Default location: checkpoints/d3qn_best.pt
    3. Falls back to random weights if not found
    
    Args:
        checkpoint_path: Optional path to checkpoint file
    """
    global _model, _model_loaded

    if _model_loaded:
        return

    # Create model with D3QN-PER training hyperparameters
    _model = DuelingDQN(
        obs_dim=OBS_DIM,
        n_actions=ACTION_DIM,
        hidden_dim=512,  # Matches training
        n_layers=4,      # Matches training
        dropout=0.0,
    )

    # Determine checkpoint location
    if checkpoint_path is None:
        # Try default locations
        script_dir = os.path.dirname(os.path.abspath(__file__))
        default_locations = [
            os.path.join(script_dir, "checkpoints", "d3qn_best.pt"),
            os.path.join(script_dir, "d3qn_best.pt"),
            os.path.join(script_dir, "checkpoints", "d3qn_final.pt"),
        ]
        
        checkpoint_path = None
        for loc in default_locations:
            if os.path.exists(loc):
                checkpoint_path = loc
                break

    # Load weights if checkpoint exists
    if checkpoint_path and os.path.exists(checkpoint_path):
        try:
            checkpoint = torch.load(checkpoint_path, map_location=torch.device("cpu"))
            
            # Handle multiple checkpoint formats:
            # 1. Direct state_dict: torch.save(model.state_dict(), path)
            # 2. D3QN-PER format: torch.save({'online_state_dict': ..., ...}, path)
            # 3. PPO format: torch.save({'net': model_state, ...}, path)
            
            state_dict = None
            
            if isinstance(checkpoint, dict):
                # Try D3QN-PER format first
                if "online_state_dict" in checkpoint:
                    state_dict = checkpoint["online_state_dict"]
                # Try PPO format (net key)
                elif "net" in checkpoint:
                    state_dict = checkpoint["net"]
                # Try standard format
                elif "state_dict" in checkpoint:
                    state_dict = checkpoint["state_dict"]
                # Check if keys look like model weights (fc1, fc2, etc.)
                elif any(key.startswith("shared") or key.startswith("value") or key.startswith("advantage") 
                        for key in checkpoint.keys()):
                    state_dict = checkpoint
                # If checkpoint is the state_dict itself
                else:
                    state_dict = checkpoint
            else:
                # Assume it's the state_dict directly
                state_dict = checkpoint
            
            # Load the state dict
            _model.load_state_dict(state_dict, strict=False)  # strict=False allows partial loading
            
            print(f"✓ Model weights loaded from: {checkpoint_path}")
        except Exception as e:
            print(f"⚠ Warning: Failed to load model weights from {checkpoint_path}: {e}")
            print("  Using random initialization instead")
    else:
        print(f"⚠ Warning: No checkpoint found")
        if checkpoint_path:
            print(f"  Searched: {checkpoint_path}")
        print("  Using random initialization (this will perform poorly)")

    # Set to evaluation mode
    _model.eval()
    _model_loaded = True


# ═══════════════════════════════════════════════════════════════════════════════
# Main Policy Function (Entry Point for Evaluation)
# ═══════════════════════════════════════════════════════════════════════════════

def policy(obs: np.ndarray, rng: np.random.Generator, checkpoint_path: Optional[str] = None) -> str:
    """
    Generate a greedy action from the current observation.
    
    This is the main function called by the Codabench evaluation system.
    Uses the trained D3QN-PER model to select the action with highest Q-value.
    
    Args:
        obs: Observation array of shape (18,) with sensor readings (0/1)
    Returns:
        Action string: one of ['L45', 'L22', 'FW', 'R22', 'R45']
    """
    # Load model on first call
    _load_model(checkpoint_path)

    # Handle frame stacking: if obs is 18-dim (single frame), repeat 4 times
    if obs.shape[0] == 18:
        obs = np.tile(obs, 4)  # Repeat to match 72-dim (4 stacked frames)
    elif obs.shape[0] != 72:
        raise ValueError(f"Expected obs_dim 18 or 72, got {obs.shape[0]}")

    # Convert observation to tensor (add batch dimension)
    obs_tensor = torch.from_numpy(obs).float().unsqueeze(0)

    # Forward pass (no gradient computation needed)
    with torch.no_grad():
        q_values = _model(obs_tensor)  # Shape: (1, 5)

    # Greedy action selection: pick action with highest Q-value
    action_idx = int(q_values.argmax(dim=1).item())

    return ACTIONS[action_idx]


# ═══════════════════════════════════════════════════════════════════════════════
# Alternative: Stochastic Policy with Temperature Scaling
# ═══════════════════════════════════════════════════════════════════════════════

def policy_with_temperature(
    obs: np.ndarray,
    rng: np.random.Generator,
    temperature: float = 1.0,
    checkpoint_path: Optional[str] = None,
) -> str:
    """
    Generate an action using temperature-scaled softmax over Q-values.
    
    This allows for stochastic action selection during evaluation.
    Useful for assessing robustness across different exploration levels.
    
    Args:
        obs: Observation array of shape (18,)
        rng: Random number generator for reproducibility
        temperature: Softmax temperature
                     - temperature → 0: greedy (argmax)
                     - temperature = 1.0: softmax(Q)
                     - temperature → ∞: uniform
    """
    _load_model(checkpoint_path)

    # Handle frame stacking: if obs is 18-dim (single frame), repeat 4 times
    if obs.shape[0] == 18:
        obs = np.tile(obs, 4)  # Repeat to match 72-dim
    elif obs.shape[0] != 72:
        raise ValueError(f"Expected obs_dim 18 or 72, got {obs.shape[0]}")

    obs_tensor = torch.from_numpy(obs).float().unsqueeze(0)

    with torch.no_grad():
        q_values = _model(obs_tensor)  # Shape: (1, 5)

    # Temperature-scaled softmax
    scaled_q = q_values / max(temperature, 1e-6)  # Avoid division by zero
    probs = torch.softmax(scaled_q, dim=1).numpy()[0]

    # Sample action using RNG for reproducibility
    action_idx = rng.choice(len(ACTIONS), p=probs)

    return ACTIONS[int(action_idx)]


# ═══════════════════════════════════════════════════════════════════════════════
# Model Management Functions
# ═══════════════════════════════════════════════════════════════════════════════

def save_model(filepath: str) -> None:
    """
    Save current model weights to disk.
    
    Args:
        filepath: Path to save checkpoint
    """
    _load_model()
    if _model is not None:
        torch.save(_model.state_dict(), filepath)
        print(f"✓ Model weights saved to: {filepath}")


def load_model(filepath: str) -> None:
    """
    Load model weights from disk.
    
    Args:
        filepath: Path to checkpoint file
    """
    global _model_loaded
    if _model is None:
        _load_model(filepath)
    else:
        _model.load_state_dict(torch.load(filepath, map_location=torch.device("cpu")))
        print(f"✓ Model weights loaded from: {filepath}")


def extract_and_save_weights(ppo_checkpoint_path: str, output_path: str) -> None:
    """
    Extract network weights from PPO checkpoint and save as a new checkpoint.
    
    This is useful for converting checkpoints saved in PPO format (with 'net' key)
    to a format that works directly with the DuelingDQN model.
    
    Args:
        ppo_checkpoint_path: Path to PPO-style checkpoint with 'net' key
        output_path: Path where to save the extracted weights
    """
    try:
        checkpoint = torch.load(ppo_checkpoint_path, map_location=torch.device("cpu"))
        
        if "net" in checkpoint:
            state_dict = checkpoint["net"]
            torch.save(state_dict, output_path)
            print(f"✓ Extracted weights from PPO checkpoint")
            print(f"✓ Saved to: {output_path}")
            print(f"  Keys in checkpoint: {list(state_dict.keys())}")
        else:
            print(f"⚠ No 'net' key found in checkpoint")
            print(f"  Available keys: {list(checkpoint.keys())}")
    except Exception as e:
        print(f"✗ Failed to extract weights: {e}")


def get_model_info() -> dict:
    """
    Get information about the loaded model.
    
    Returns:
        Dictionary with model architecture and parameter count
    """
    _load_model()
    
    if _model is None:
        return {"error": "Model not loaded"}
    
    total_params = sum(p.numel() for p in _model.parameters())
    trainable_params = sum(p.numel() for p in _model.parameters() if p.requires_grad)
    
    return {
        "model_class": "DuelingDQN",
        "obs_dim": _model.obs_dim,
        "n_actions": _model.n_actions,
        "total_parameters": total_params,
        "trainable_parameters": trainable_params,
        "device": "cpu",
        "eval_mode": not _model.training,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Batch Inference (For Evaluation Scripts)
# ═══════════════════════════════════════════════════════════════════════════════

def policy_batch(
    obs_batch: np.ndarray,
    rng: np.random.Generator,
    checkpoint_path: Optional[str] = None,
) -> np.ndarray:
    """
    Generate actions for a batch of observations.
    
    Args:
        obs_batch: Batch of observations, shape (batch_size, 18)
        rng: Random number generator
        checkpoint_path: Optional path to model checkpoint
        
    Returns:
        Array of action indices, shape (batch_size,)
    """
    _load_model(checkpoint_path)

    obs_tensor = torch.from_numpy(obs_batch).float()

    with torch.no_grad():
        q_values = _model(obs_tensor)  # Shape: (batch_size, 5)

    action_indices = q_values.argmax(dim=1).numpy()

    return action_indices


# ═══════════════════════════════════════════════════════════════════════════════
# Testing & Debugging
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    """Quick test of the policy functions."""
    
    print("=" * 80)
    print("D3QN-PER Policy Evaluation Test")
    print("=" * 80)

    # Create a test observation (18-bit binary sensor input)
    test_obs = np.array(
        [0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0],
        dtype=np.float32,
    )

    # Create RNG
    rng = np.random.default_rng(seed=42)

    # Test greedy policy
    print("\n✓ Testing greedy policy...")
    try:
        for i in range(5):
            action = policy(test_obs, rng)
            print(f"  Step {i+1}: {action}")
        print("  Greedy policy: ✓ OK")
    except Exception as e:
        print(f"  Greedy policy: ✗ FAILED ({e})")

    # Test stochastic policy
    print("\n✓ Testing stochastic policy (temperature=2.0)...")
    try:
        for i in range(5):
            action = policy_with_temperature(test_obs, rng, temperature=2.0)
            print(f"  Step {i+1}: {action}")
        print("  Stochastic policy: ✓ OK")
    except Exception as e:
        print(f"  Stochastic policy: ✗ FAILED ({e})")

    # Test batch inference
    print("\n✓ Testing batch inference...")
    try:
        batch_obs = np.tile(test_obs, (5, 1))
        actions = policy_batch(batch_obs, rng)
        print(f"  Batch size: 5")
        print(f"  Actions: {[ACTIONS[idx] for idx in actions]}")
        print("  Batch inference: ✓ OK")
    except Exception as e:
        print(f"  Batch inference: ✗ FAILED ({e})")

    # Print model info
    print("\n✓ Model Information:")
    try:
        info = get_model_info()
        for key, value in info.items():
            print(f"  {key}: {value}")
    except Exception as e:
        print(f"  Model info: ✗ FAILED ({e})")

    print("\n" + "=" * 80)
    print("✓ All tests completed!")
    print("=" * 80)
